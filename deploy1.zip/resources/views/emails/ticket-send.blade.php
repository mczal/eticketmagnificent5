Terima kasih karena telah membeli tiket untuk Five Live Magnificent. <br>
Silakan unduh <i>e-ticket</i> yang kami lampirkan dalam e-mail ini.<br>
Tunjukkan <i>e-ticket</i> tersebut pada hari-H sebagai tanda masuk Anda.<br>
Anda harus mencetak <i>e-ticket</i> tersebut untuk memudahkan proses verifikasi di hari-H. <br>
Perhatikan bahwa satu pdf <i>e-ticket</i> hanya mewakili satu tiket. <br>
Sediakan juga kartu identitas Anda untuk memudahkan proses verifikasi pada saat acara.
<br><br>
Untuk informasi lebih lanjut, silakan hubungi call center kami.
<br><br>
Hormat kami,
<br><br>
SMA Negeri 5 Bandung <br>
Twitter: flmagnificent
<br><br>
Five Live Magnificent 2016
<br><br>
================================================================================
<br><br>
Thank you for your confirmation for Five Live Magnificent.<br>
Please download your <i>e-ticket</i> in the attachment below.<br>
Indicate the <i>e-ticket</i> on D-Day as a sign of your entry.<br>
You must print the <i>e-ticket</i> to facilitate the verification process in the D-day.<br>
Note that the pdf <i>e-tickets</i> represent just one ticket.<br>
Please provide your identity card to facilitate the verification process during the event.<br>
<br>
For further information, please contact our call center.
<br><br>
Best regards,
<br><br>
SMA Negeri 5 Bandung <br>
Twitter: flmagnificent
<br><br>
Five Live Magnificent 2016
