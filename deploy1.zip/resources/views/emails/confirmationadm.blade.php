New confirmation has been received. <br>
Please procees this order within 1x24 hours <br>
Costumer billing detail : <br>
Nama : {{$confirmation->order->name}} <br>
Rekening : {{$confirmation->no_rekening}} <br>
Nama Bank : {{$confirmation->nama_bank}} <br>
Total Transfer : {{$confirmation->total_transfer}} <br>
