Your confirmation has been received. <br>
Your order will be process within 1x24 hours <br>
Your billing detail : <br>
Rekening : {{$confirmation->no_rekening}} <br>
Nama Bank : {{$confirmation->nama_bank}} <br>
Total Transfer : {{$confirmation->total_transfer}} <br>
