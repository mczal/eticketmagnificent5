<?php $__env->startSection('title', 'Statistics'); ?>
<?php $__env->startSection('header', 'Statistics'); ?>
<?php $__env->startSection('subheader', 'Type List'); ?>

<?php $__env->startSection('content'); ?>
    <p>
        <a href="<?php echo e(url('/statistics' )); ?>" class="btn btn-primary"><i class="fa fa-bars"></i> View List</a>
    </p>
    <div class="box box-solid">
        <div class="box-body">
            <?php echo $__env->make('commons.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Active</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($types) == 0): ?>
                        <tr>
                            <td colspan="4" align="center">No data found ...</td>
                        </tr>
                    <?php endif; ?>
                    <?php foreach($types as $type): ?>
                        <tr>
                            <td><?php echo e($type->id); ?></td>
                            <td><?php echo e($type->name); ?></td>
                            <td><?php echo e(number_format($type->price)); ?></td>
                            <td><?php echo e($type->active == 1 ? 'Active' : 'Not Active'); ?></td>
                            <td>
                                <a href="<?php echo e(url('/statistics/'.$type->id)); ?>" class="btn btn-default"><i class="fa fa-eye"></i> View Detail</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div><!-- /.box-body -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>