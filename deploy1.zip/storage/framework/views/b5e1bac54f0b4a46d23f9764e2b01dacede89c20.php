<?php $__env->startSection('title', 'Confirmations'); ?>
<?php $__env->startSection('header', 'Confirmations'); ?>

<?php $__env->startSection('content'); ?>

<!--
  <p>
      <a class="btn btn-primary" href=<?php echo e(url('/confirmations/create')); ?> role="button"><i class="fa fa-plus"></i> Create New</a>
  </p>
-->
  <div class="box box-solid">
  <div class="box-body">
    <p>
        <form action="<?php echo e(url('/confirmations')); ?>" method="get">
            <div class="input-group">
              <select class="form-control" name="status">
                <option value="-1"<?php echo e(app('request')->input('status') == -1 ? ' selected' : ''); ?>>Semua</option>
                <option value="0"<?php echo e(app('request')->input('status') == 0 ? ' selected' : ''); ?>>Belum divalidasi</option>
                <option value="1"<?php echo e(app('request')->input('status') == 1 ? ' selected' : ''); ?>>Sudah tervalidasi</option>
              </select>
                <span class="input-group-btn">
                    <button class="btn btn-info btn-flat" type="submit"><i class="fa fa-search"></i></button>
                </span>
            </div>
        </form>
    </p>
  <table class="table table-hover">
    <thead>
      <tr>
        <th>Validate</th>
        <th>Order</th>
        <th>No Rekening</th>
        <th>Nama Pemilik Bank</th>
        <th>Nama Bank</th>
        <th>Total Transfer</th>
        <th>Created At</th>
        <th></th>
      </tr>
    </thead>
    <?php if( count($confirmations) > 0): ?>
      <tbody>
        <?php foreach($confirmations as $confirmation): ?>
          <tr>
            <td>
              <?php if($confirmation->status == 0): ?>
                <form style="display:inline" action="<?php echo e(url('/confirmations/validate')); ?>" method="post">
                  <?php echo csrf_field(); ?>

                  <input readOnly type="hidden" type="number" name="id" value="<?php echo e($confirmation->id); ?>">
                  <button type="submit" class="btn btn-success" onclick="return confirm('All tickets registered will be active !')">Validate</button>
                </form>
              <?php else: ?>
              <button class="btn btn-default" disabled>Valid</button>
              <?php endif; ?>
            </td>
            <td><a href="<?php echo e(url('/orders/' . $confirmation->order->id)); ?>" target="_blank"><?php echo $confirmation->order->no_order . '<br>' . $confirmation->order->name; ?></a></td>
            <td><?php echo e($confirmation->no_rekening); ?></td>
            <td><?php echo e($confirmation->name); ?></td>
            <td><?php echo e($confirmation->nama_bank); ?></td>
            <td><?php echo e(number_format($confirmation->total_transfer)); ?></td>
            <td><?php echo e($confirmation->created_at); ?></td>
            <td>
              <a href="<?php echo e(url('/confirmations/'.$confirmation->id)); ?>" class="btn btn-default"><i class="fa fa-eye"></i></a>
            <!--
              <a href="<?php echo e(url('/confirmations/'.$confirmation->id.'/edit')); ?>" class="btn btn-default"><i class="fa fa-pencil"></i></a>
            -->
              <form style="display:inline" action="<?php echo e(url('/confirmations/'.$confirmation->id)); ?>" method="post">
                <?php echo csrf_field(); ?>

                <?php echo method_field('DELETE'); ?>


                <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure want to delete this item?')"><i class="fa fa-trash-o"></i></button>

              </form>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    <?php endif; ?>
  </table>
</div>
</div>
  <?php echo $confirmations->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>