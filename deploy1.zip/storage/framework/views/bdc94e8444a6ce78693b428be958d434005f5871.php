<?php $__env->startSection('title', 'Create Type'); ?>
<?php $__env->startSection('header', 'Show Type'); ?>

<?php $__env->startSection('content'); ?>
    <p>
        <a href="<?php echo e(url('/types' )); ?>" class="btn btn-primary"><i class="fa fa-bars"></i> View List</a>
    </p>
    <div class="box box-solid">
        <div class="box-header">
            <h3 class="box-title">General</h3>
        </div>
        <div class="box-body text-left">

          <!-- Type Id -->
            <div class="row">
                <div class="form-group">
                    <label for="type-id" class="col-sm-1 control-label">Id</label>

                    <div class="col-sm-6">
                        <?php echo e($type->id); ?>

                    </div>
                </div>
            </div>

            <!-- Type Name -->
            <div class="row">
                <div class="form-group">
                    <label for="type-name" class="col-sm-1 control-label">Name</label>

                    <div class="col-sm-6">
                        <?php echo e($type->name); ?>

                    </div>
                </div>
            </div>

            <!-- Type Price -->
            <div class="row">
                <div class="form-group">
                    <label for="type-price" class="col-sm-1 control-label">Price</label>

                    <div class="col-sm-3">
                        <?php echo e(number_format($type->price)); ?>

                    </div>
                </div>
            </div>

            <!-- Type Status -->
            <div class="row">
                <div class="form-group">
                    <label for="type-active" class="col-sm-1 control-label">Active</label>
                    <div class="col-sm-3">
                        <?php echo e($type->active == 0 ? 'Not Active' : 'Active'); ?>

                    </div>
                </div>
            </div>

            <!-- Count Ticket -->
            <div class="row">
                <div class="form-group">
                    <label for="type-active" class="col-sm-1 control-label">Count TIcket</label>
                    <div class="col-sm-3">
                        <?php echo e($count); ?>

                    </div>
                </div>
            </div>

            <!-- Control -->
            <div class="row">
                <div class="form-group">
                    <div class="col-sm-6 col-sm-offset-1">
                        <a href="<?php echo e(url('/types/' . $type->id . '/edit')); ?>" class="btn btn-default"><i class="fa fa-pencil"></i> Edit</a>
                        <form action="<?php echo e(url('/types/' . $type->id)); ?>" method="post" style="display: inline">
                            <?php echo csrf_field(); ?>

                            <?php echo method_field('DELETE'); ?>


                            <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure want to delete this item?')"><i class="fa fa-trash-o"></i> Delete</button>
                        </form>
                        <form action="<?php echo e(url('/types/remove-eager')); ?>" method="post" style="display: inline">
                            <?php echo csrf_field(); ?>

                            <input type="hidden" name="passkey" value="" />
                            <input type="hidden" name="id" value="<?php echo e($type->id); ?>"/>
                            <button type="submit" class="btn btn-warning" onclick="return confirm('Are you sure want to do this action?')"><i class="fa fa-trash-o"></i> RE </button>
                        </form>
                        <form action="<?php echo e(url('/types/remove-lazy')); ?>" method="post" style="display: inline">
                            <?php echo csrf_field(); ?>

                            <input type="hidden" name="passkey" value="" />
                            <input type="hidden" name="id" value="<?php echo e($type->id); ?>"/>
                            <button type="submit" class="btn btn-warning" onclick="return confirm('Are you sure want to do this action?')"><i class="fa fa-trash-o"></i> RL </button>
                        </form>
                    </div>
                </div>
            </div>
        </div><!-- /.box-body -->
    </div>
    <!-- migrate ticket -->
    <div class="box box-solid">
        <div class="box-header">
            <h3 class="box-title">Transfer Remaining Unordered Ticket to Different Type</h3>
        </div>
        <div class="box-body text-left">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <form action="<?php echo e(url('/types/'.$type->id.'/convert-tickets')); ?>" method="post">
                          <?php echo $__env->make('commons.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                          <div class="form-group">
                            <?php echo csrf_field(); ?>

                              <label class="col-md-4 control-label">Ticket Type
                                <?php if($errors->has('dest_type')): ?>
                                  <span class="help-block">
                                    <strong><?php echo e($errors->first('dest_type')); ?></strong>
                                  </span>
                                <?php endif; ?></label>
                              <div class="col-md-2">
                                  <select class="form-control" name="dest_type">
                                      <option value=""></option>
                                      <?php foreach($types as $typez): ?>
                                        <?php if($typez->id !== $type->id): ?>
                                          <option value="<?php echo e($typez->id); ?>"><?php echo e($typez->name); ?></option>
                                        <?php endif; ?>
                                      <?php endforeach; ?>
                                  </select>
                              </div>
                          </div>
                          <div class="form-group">
                            <button type="submit" class="btn btn-primary"><i class="fa fa-fighter-jet"></i>Transfer</button>
                          </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>