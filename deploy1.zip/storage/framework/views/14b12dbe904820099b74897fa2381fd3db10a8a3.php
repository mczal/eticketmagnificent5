<?php $__env->startSection('title', 'Add Tickets'); ?>
<?php $__env->startSection('header', 'Add Tickets'); ?>

<?php $__env->startSection('content'); ?>
<div class="box box-solid">
    <div class="box-body">
        <form class="form-horizontal" action=<?php echo e(url('/tickets')); ?> role="form" method="POST">
            <?php echo csrf_field(); ?>


            <div class="form-group">
                <label class="col-md-4 control-label">Ticket Type</label>
                <div class="col-md-6">
                    <select class="form-control" name="type">
                        <option value=""></option>
                        <?php foreach($types as $type): ?>
                            <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-4 control-label">Amount</label>
                <div class="col-md-6">
                    <input type="number" class="form-control" name="amount">
                </div>
            </div>

            <div class="form-group">
              <button type="submit" class="btn btn-danger col-md-offset-6">Generate</button>
            </div>

        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>