<?php $__env->startSection('title', 'Create Type'); ?>
<?php $__env->startSection('header', 'Create New'); ?>
<?php $__env->startSection('subheader', 'Create New Type'); ?>

<?php $__env->startSection('content'); ?>
    <p>
        <a href="<?php echo e(url('/types' )); ?>" class="btn btn-primary"><i class="fa fa-bars"></i> View List</a>
    </p>
    <div class="box box-solid">
        <div class="box-header">
            <h3 class="box-title">General</h3>
        </div>
        <div class="box-body text-left">
            <form class="form-horizontal" action="<?php echo e(url('/types')); ?>" method="post">
                <?php echo csrf_field(); ?>

                <?php echo $__env->make('types._form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <div class="form-group">
                    <div class="col-sm-3 col-sm-offset-1">
                        <button type="submit" name="button" class="btn btn-success"><i class="fa fa-save"></i> Save</button>
                    </div>
                </div>
            </form>
        </div><!-- /.box-body -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>