Thank you for your confirmation, the following it your detailed purchase : <br>
<br>
Payment Information : <br>
Name : <?php echo e($confirmation->name); ?> <br>
Order No. : <?php echo e($confirmation->order->no_order); ?> <br>
Quantity : <?php echo e($confirmation->order->quantity); ?> <br>
Total : Rp.<?php echo e($confirmation->total_transfer); ?> <br>
<br>
Your ticket was attached on this email. If the attachment failed to accessed,
please contact <br>
081288533739 (Akbar) <br>
085921231626 (Andin) <br>
<br>
We hope you enjoy Parahyangan Fair Festival 2016! <br>
<br>
=========================================================== <br>
<br>
Terima kasih telah melakukan konfirmasi pembayaran, berikut adalah detail pemesanan anda : <br>
<br>
Informasi Pemesanan : <br>
Nama : <?php echo e($confirmation->name); ?> <br>
No. Order : <?php echo e($confirmation->order->no_order); ?> <br>
Kuantitas : <?php echo e($confirmation->order->quantity); ?> <br>
Total : Rp.<?php echo e($confirmation->total_transfer); ?> <br>
<br>
Tiket anda telah terikirim dengan lampiran berikut. Jika lampiran tidak tercantumkan,
silahkan hubungi <br>
081288533739 (Akbar) <br>
085921231626 (Andin) <br>
<br>
Selamat menikmati Festival Parahyangan Fair 2016! <br>
<br>
