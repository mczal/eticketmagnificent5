<?php $__env->startSection('background',"url('/assets/images/background.jpg')no-repeat center center fixed;-webkit-background-size: cover;
-moz-background-size: cover;
-o-background-size: cover;
background-size: cover;"); ?>
<?php $__env->startSection('content'); ?>
<div class = "container" style="padding-top:100px">
    <p style="text-align:center;"><img src="<?php echo e(asset('assets/images/payment.png')); ?>" width="300" height="auto"></p>
    <div class = "row">
        <div class="col-lg-6 col-lg-offset-3 col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2 col-xs-10 col-xs-offset-1" style="background:rgba(38,38,38,0.7); padding-bottom: 20px;">
            <?php echo $__env->make('commons.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <form method="post" action="<?php echo e(url('/confirmation')); ?>" role="form">
                <?php echo csrf_field(); ?>

                <div class="form-group<?php echo e($errors->has('nama_bank') ? ' has-error' : ''); ?>">
                    <div class="col-sm-12">
                        <label for="nama_bank">Bank:
    					<?php if($errors->has('nama_bank')): ?>
    			            <span class="help-block">
    			                <strong><?php echo e($errors->first('nama_bank')); ?></strong>
    			            </span>
    			        <?php endif; ?></label>
                        <input type="text" class="form-control" id="nama_bank" name="nama_bank" value="<?php echo e(old('nama_bank')); ?>">
                    </div>
                </div>
                <div class="form-group<?php echo e($errors->has('no_rekening') ? ' has-error' : ''); ?>">
                    <div class="col-sm-12">
                        <label for="no_rekening">Bank Account Number:
    					<?php if($errors->has('no_rekening')): ?>
    			            <span class="help-block">
    			                <strong><?php echo e($errors->first('no_rekening')); ?></strong>
    			            </span>
    			        <?php endif; ?></label>
                        <input type="text" class="form-control" id="no_rekening" name="no_rekening" value="<?php echo e(old('no_rekening')); ?>">
                    </div>
                </div>
                <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                    <div class="col-sm-12">
                        <label for="name">Name (exactly as in Bank):
    					<?php if($errors->has('name')): ?>
    			            <span class="help-block">
    			                <strong><?php echo e($errors->first('name')); ?></strong>
    			            </span>
    			        <?php endif; ?></label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name')); ?>">
                    </div>
                </div>
                <div class="form-group<?php echo e($errors->has('total_transfer') ? ' has-error' : ''); ?>">
                    <div class="col-sm-12">
                        <label for="total_transfer">Transfer Amount:
    					<?php if($errors->has('total_transfer')): ?>
    			            <span class="help-block">
    			                <strong><?php echo e($errors->first('total_transfer')); ?></strong>
    			            </span>
    			        <?php endif; ?></label>
                        <input type="number" class="form-control" id="total_transfer" name="total_transfer" value="<?php echo e(old('total_transfer')); ?>">
                    </div>
                </div>
                <div class="form-group<?php echo e($errors->has('no_order') ? ' has-error' : ''); ?>">
                    <div class="col-sm-12">
                        <label for="no_order">No Order:
    					<?php if($errors->has('no_order')): ?>
    			            <span class="help-block">
    			                <strong><?php echo e($errors->first('no_order')); ?></strong>
    			            </span>
    			        <?php endif; ?></label>
                        <input type="text" class="form-control" id="no_order" name="no_order" value="<?php echo e(old('no_order')); ?>">
                    </div>
                </div>
                <div class="col-sm-12">
                    <br>
                    <button id ="second" style="font-size:11pt;" class="btn btn-small btn-primary btn-block" type="submit" role="button">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>