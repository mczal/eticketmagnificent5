<?php $__env->startSection('title', 'Statistic Detail'); ?>
<?php $__env->startSection('header', 'Statistic'); ?>

<?php $__env->startSection('content'); ?>
<p>
    <a href="<?php echo e(url('/statistics' )); ?>" class="btn btn-primary"><i class="fa fa-bars"></i> View List</a>
</p>
<div class="box box-solid">
    <div class="box-header">
        <h3 class="box-title">General</h3>
    </div>
    <div class="box-body text-left">
        <div class="container">

            <!-- Type ID -->
            <div class="row">
                <div class="form-group">
                    <label class="col-sm-2 control-label">ID</label>
                    <div class="col-sm-6">
                        <?php echo e($type->id); ?>

                    </div>
                </div>
            </div>

            <!-- Type Name -->
            <div class="row">
                <div class="form-group">
                    <label class="col-sm-2 control-label">Name</label>
                    <div class="col-sm-6">
                        <?php echo e($type->name); ?>

                    </div>
                </div>
            </div>

            <!-- Type Price -->
            <div class="row">
                <div class="form-group">
                    <label class="col-sm-2 control-label">Price</label>
                    <div class="col-sm-6">
                        <?php echo e($type->price); ?>

                    </div>
                </div>
            </div>

            <!-- Type Status -->
            <div class="row">
                <div class="form-group">
                    <label class="col-sm-2 control-label">Status</label>
                    <div class="col-sm-6">
                       <?php echo e($type->active == 1 ? 'Active' : 'Not Active'); ?>

                    </div>
                </div>
            </div>

            <!-- Total Tickets -->
            <div class="row">
                <div class="form-group">
                    <label class="col-sm-2 control-label">Total Tickets</label>
                    <div class="col-sm-6">
                        <?php echo e($total); ?>

                    </div>
                </div>
            </div>

            <!-- Type Remaining Av. Ticket -->
            <div class="row">
                <div class="form-group">
                    <label class="col-sm-2 control-label">Remaining Tickets</label>
                    <div class="col-sm-6">
                        <?php echo e($remaining); ?>

                    </div>
                </div>
            </div>

            <!-- Type Total -->
            <div class="row">
                <div class="form-group">
                    <label class="col-sm-2 control-label">Total Ticket</label>
                    <div class="col-sm-6">
                        <?php echo e($total); ?>

                    </div>
                </div>
            </div>

            <!-- Ordered Tickets Count -->
            <div class="row">
                <div class="form-group">
                    <label class="col-sm-2 control-label">Ordered Ticket Count</label>
                    <div class="col-sm-6">
                        <?php echo e($ordered); ?>

                    </div>
                </div>
            </div>

            <!-- Actived Tickets Count -->
            <div class="row">
                <div class="form-group">
                    <label class="col-sm-2 control-label">Actived Ticket Count</label>
                    <div class="col-sm-6">
                        <?php echo e($actived); ?>

                    </div>
                </div>
            </div>

            <!-- CheckedIn Tickets Count -->
            <div class="row">
                <div class="form-group">
                    <label class="col-sm-2 control-label">CheckedIn Ticket Count</label>
                    <div class="col-sm-6">
                        <?php echo e($checkedIn); ?>

                    </div>
                </div>
            </div>

            <!-- SLNDLMDLKSMDL TODO DELETE -->

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>