<!-- Type Name -->
<div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
    <label for="type-name" class="col-sm-1 control-label">Name</label>

    <div class="col-sm-6">
        <input type="text" name="name" id="type-name" class="form-control" value="<?php echo e(isset($type->name) ? $type->name : ''); ?>">
        <?php if($errors->has('name')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('name')); ?></strong>
            </span>
        <?php endif; ?>
    </div>
</div>

<!-- Type Price -->
<div class="form-group<?php echo e($errors->has('price') ? ' has-error' : ''); ?>">
    <label for="type-price" class="col-sm-1 control-label">Price</label>

    <div class="col-sm-3">
        <input type="text" name="price" id="type-price" class="form-control" value="<?php echo e(isset($type->price) ? $type->price : 0); ?> ">
        <?php if($errors->has('price')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('price')); ?></strong>
            </span>
        <?php endif; ?>
    </div>
</div>

<!-- Type Status -->
<div class="form-group">
    <label for="type-active" class="col-sm-1 control-label">Active</label>
    <div class="col-sm-3">
        <select class="form-control" name="active">
            <option value="0"<?php echo e((isset($type->active) && $type->active == 0) ? ' selected' : ''); ?>>Not Active</option>
            <option value="1"<?php echo e((isset($type->active) && $type->active == 1) ? ' selected' : ''); ?>>Active</option>
        </select>
    </div>
</div>
