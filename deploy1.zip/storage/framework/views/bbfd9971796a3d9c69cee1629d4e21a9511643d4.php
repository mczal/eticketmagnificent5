<!-- Name -->
<div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
    <label for="order-name" class="col-sm-2 control-label">Name</label>

    <div class="col-sm-6">
        <input type="text" name="name" id="order-name" class="form-control" value="<?php echo e(app('request')->input('name')); ?>">
        <?php if($errors->has('name')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('name')); ?></strong>
            </span>
        <?php endif; ?>
    </div>
</div>

<!-- Email -->
<div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
    <label for="order-email" class="col-sm-2 control-label">Email</label>

    <div class="col-sm-6">
        <input type="email" name="email" id="order-email" class="form-control" value="<?php echo e(app('request')->input('email')); ?>">
        <?php if($errors->has('email')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('email')); ?></strong>
            </span>
        <?php endif; ?>
    </div>
</div>

<!-- Handphone -->
<div class="form-group<?php echo e($errors->has('handphone') ? ' has-error' : ''); ?>">
    <label for="order-handphone" class="col-sm-2 control-label">Handphone</label>

    <div class="col-sm-6">
        <input type="text" name="handphone" id="order-handphone" class="form-control" value="<?php echo e(app('request')->input('handphone')); ?>"/>
        <?php if($errors->has('handphone')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('handphone')); ?></strong>
            </span>
        <?php endif; ?>
    </div>
</div>

<!-- TICKET TYPE -->
<div class="form-group<?php echo e($errors->has('ctfest1') ? ' has-error' : ''); ?>">
    <label for="order-ctfest1" class="col-sm-2 control-label">Ticket Type</label>
    <div class="col-sm-6">

      <label class="col-sm-2 control-label">FESTIVAL</label>
      <?php if($errors->has('ctfest1')): ?>
          <span class="help-block">
              <strong><?php echo e($errors->first('ctfest1')); ?></strong>
          </span>
      <?php endif; ?>
      <input type="number" name="ctfest1" id="order-ctfest1" class="form-control" value="0"/>
      <label class="col-sm-2 control-label">VIP A</label>
      <?php if($errors->has('ctvipa2')): ?>
          <span class="help-block">
              <strong><?php echo e($errors->first('ctvipa2')); ?></strong>
          </span>
      <?php endif; ?>
      <input type="number" name="ctvipa2" id="order-ctvipa2" class="form-control" value="0"/>
      <label class="col-sm-2 control-label">VIP B</label>
      <?php if($errors->has('ctvipb3')): ?>
          <span class="help-block">
              <strong><?php echo e($errors->first('ctvipb3')); ?></strong>
          </span>
      <?php endif; ?>
      <input type="number" name="ctvipb3" id="order-ctvipb3" class="form-control" value="0"/>
      <label class="col-sm-2 control-label">VVIP</label>
      <?php if($errors->has('ctvvip4')): ?>
          <span class="help-block">
              <strong><?php echo e($errors->first('ctvvip4')); ?></strong>
          </span>
      <?php endif; ?>
      <input type="number" name="ctvvip4" id="order-ctvvip4" class="form-control" value="0"/>
    </div>
</div>

<!-- ID Number
<div class="form-group<?php echo e($errors->has('id_no') ? ' has-error' : ''); ?>">
    <label for="order-id_no" class="col-sm-2 control-label">ID Number</label>

    <div class="col-sm-6">
        <input type="text" name="id_no" id="order-id_no" class="form-control" value="<?php echo e(isset($order->id_no) ? $order->id_no : old('id_no')); ?>">
        <?php if($errors->has('id_no')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('id_no')); ?></strong>
            </span>
        <?php endif; ?>
    </div>
</div>-->

<!-- Quantity
<div class="form-group<?php echo e($errors->has('quantity') ? ' has-error' : ''); ?>">
    <label for="order-quantity" class="col-sm-2 control-label">Quantity</label>

    <div class="col-sm-2">
        <input type="number" name="quantity" id="order-quantity" class="form-control" value="<?php echo e(isset($order->quantity) ? $order->quantity : old('quantity')); ?>">
        <?php if($errors->has('quantity')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('quantity')); ?></strong>
            </span>
        <?php endif; ?>
    </div>
</div>
-->
