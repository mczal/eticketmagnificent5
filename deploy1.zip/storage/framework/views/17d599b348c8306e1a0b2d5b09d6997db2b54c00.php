<?php $__env->startSection('title', 'Confirmation ID ' . $confirmation->id); ?>
<?php $__env->startSection('header', 'Confirmation'); ?>
<?php $__env->startSection('subheader', 'ID ' . $confirmation->id); ?>
<?php $__env->startSection('content'); ?>
<p>
    <a href="<?php echo e(url('/confirmations' )); ?>" class="btn btn-primary"><i class="fa fa-bars"></i> View List</a>
</p>
<div class="box box-solid">
    <div class="box-header">
        <h3 class="box-title">General</h3>
    </div>
    <div class="box-body text-left">
        <!-- ID -->
        <div class="row">
            <div class="form-group">
                <label for="id" class="col-sm-2 control-label">Id</label>

                <div class="col-sm-6">
                    <?php echo e($confirmation->id); ?>

                </div>
            </div>
        </div>

        <!-- Order Id -->
        <div class="row">
            <div class="form-group">
                <label for="order-id" class="col-sm-2 control-label">Order Id</label>

                <div class="col-sm-6">
                    <a href="<?php echo e(url('/orders/' . $confirmation->order->id)); ?>"><?php echo e($confirmation->order->no_order); ?></a>
                </div>
            </div>
        </div>

        <!-- Nama Bank -->
        <div class="row">
            <div class="form-group">
                <label for="nama-bank" class="col-sm-2 control-label">Bank</label>

                <div class="col-sm-6">
                    <?php echo e($confirmation->nama_bank); ?>

                </div>
            </div>
        </div>

        <!-- No Rekening -->
        <div class="row">
            <div class="form-group">
                <label for="no_rekening" class="col-sm-2 control-label">No Rekening</label>

                <div class="col-sm-6">
                    <?php echo e($confirmation->no_rekening); ?>

                </div>
            </div>
        </div>

        <!-- Nama di Bank -->
        <div class="row">
            <div class="form-group">
                <label for="name" class="col-sm-2 control-label">Nama Pemilik Bank</label>
                <div class="col-sm-6">
                    <?php echo e($confirmation->name); ?>

                </div>
            </div>
        </div>

        <!-- Total Transfer -->
        <div class="row">
            <div class="form-group">
                <label for="total-transfer" class="col-sm-2 control-label">Total Transfer</label>

                <div class="col-sm-6">
                    IDR <?php echo e(number_format($confirmation->total_transfer)); ?>

                </div>
            </div>
        </div>

        <!-- Created At -->
        <div class="row">
            <div class="form-group">
                <label for="created-at" class="col-sm-2 control-label">Created At</label>

                <div class="col-sm-6">
                    <?php echo e($confirmation->created_at); ?>

                </div>
            </div>
        </div>

        <!-- Updated At -->
        <div class="row">
            <div class="form-group">
                <label for="updated-at" class="col-sm-2 control-label">Updated At</label>

                <div class="col-sm-6">
                    <?php echo e($confirmation->updated_at); ?>

                </div>
            </div>
        </div>

        <!-- Control -->
        <div class="row">
          <!--delete-->
            <div class="form-group">
                <div class="col-sm-6 col-sm-offset-2">
                  <!-- validate -->
                  <?php if($confirmation->status == 0): ?>
                    <form style="display:inline" action="<?php echo e(url('/confirmations/validate')); ?>" method="post">
                      <?php echo csrf_field(); ?>

                      <input readOnly type="hidden" type="number" name="id" value="<?php echo e($confirmation->id); ?>">
                      <button type="submit" class="btn btn-success" onclick="return confirm('All tickets registered will be active !')">Validate</button>
                    </form>
                  <?php else: ?>
                  <button class="btn btn-default" disabled>Valid</button>
                  <?php endif; ?>
                    <a href="<?php echo e(url('/confirmations/' . $confirmation->id . '/edit')); ?>" class="btn btn-default"><i class="fa fa-pencil"></i> Edit</a>
                    <form action="<?php echo e(url('/confirmations/' . $confirmation->id)); ?>" method="post" style="display: inline">
                        <?php echo csrf_field(); ?>

                        <?php echo method_field('DELETE'); ?>


                        <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure want to delete this item?')"><i class="fa fa-trash-o"></i> Delete</button>
                    </form>
                </div>
                <div class="col-sm-6 col-sm-offset-2">
                    <form style="display:inline" action="<?php echo e(url('/confirmations/resendMail')); ?>" method="post">
                      <?php echo csrf_field(); ?>

                      <input readOnly type="hidden" type="number" name="id" value="<?php echo e($confirmation->id); ?>">
                      <button type="submit" class="btn btn-primary" onclick="return confirm('Send email contain its ticket again?')"><i class="fa fa-share">Send Mail</i></button>
                    </form>
                </div>
            </div>
        </div>
    </div><!-- /.box-body -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>