<?php $__env->startSection('content'); ?>
<p>
    <a href="<?php echo e(url('/confirmations')); ?>" class="btn btn-primary"><i class="fa fa-bars"></i> View List</a>
</p>
<div class="box box-solid">
    <div class="box-header">
        <h3 class="box-title">General</h3>
    </div>
    <div class="box-body text-left">
        <form class="form-horizontal" action="<?php echo e(url('/confirmations/' . $confirmation->id)); ?>" method="post">
            <?php echo csrf_field(); ?>

            <?php echo method_field('PATCH'); ?>


            <!--ID LABEL-->
            <div class="form-group">
                <label for="confirmation-id" class="col-sm-2 control-label">Id</label>
                <div class="col-sm-6">
                    <input readonly type="text" name="id" id="confirmation-id" class="form-control" value="<?php echo e($confirmation->id); ?>">
                </div>
            </div>

            <!-- No Rekening -->
            <div class="form-group<?php echo e($errors->has('no_rekening') ? ' has-error' : ''); ?>">
                <label for="no_rekening" class="col-sm-2 control-label">No. Rekening</label>
                <div class="col-sm-6">
                    <input type="text" name="no_rekening" id="no_rekening" class="form-control" value="<?php echo e(isset($confirmation->no_rekening) ? $confirmation->no_rekening : ''); ?>">
                    <?php if($errors->has('no_rekening')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('no_rekening')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Nama Bank -->
            <div class="form-group<?php echo e($errors->has('nama_bank') ? ' has-error' : ''); ?>">
                <label for="nama_bank" class="col-sm-2 control-label">Nama Bank</label>
                <div class="col-sm-6">
                    <input type="text" name="nama_bank" id="nama_bank" class="form-control" value="<?php echo e(isset($confirmation->nama_bank) ? $confirmation->nama_bank : ''); ?>">
                    <?php if($errors->has('nama_bank')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('nama_bank')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Total Transfer -->
            <div class="form-group<?php echo e($errors->has('total_transfer') ? ' has-error' : ''); ?>">
                <label for="total_transfer" class="col-sm-2 control-label">Total Transfer</label>
                <div class="col-sm-6">
                    <input type="text" name="total_transfer" id="total_transfer" class="form-control" value="<?php echo e(isset($confirmation->total_transfer) ? $confirmation->total_transfer : ''); ?>">
                    <?php if($errors->has('total_transfer')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('total_transfer')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>


            <div class="form-group">
                <div class="col-sm-3 col-sm-offset-1">
                    <button type="submit" name="button" class="btn btn-success"><i class="fa fa-save"></i> Save</button>
                </div>
            </div>

        </form>
    </div><!-- /.box-body -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>