<?php $__env->startSection('title', 'Create Order'); ?>
<?php $__env->startSection('header', 'Create New'); ?>
<?php $__env->startSection('subheader', 'Create New Order'); ?>

<?php $__env->startSection('content'); ?>
    <p>
        <a href="<?php echo e(url('/orders' )); ?>" class="btn btn-primary"><i class="fa fa-bars"></i> View List</a>
    </p>
    <div class="box box-solid">
        <div class="box-header">
            <h3 class="box-title">General</h3>
        </div>
        <div class="box-body text-left">
            <form class="form-horizontal" action="<?php echo e(url('/orders')); ?>" method="post">
                <?php echo csrf_field(); ?>

                <?php echo $__env->make('commons.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('orders._form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <div class="form-group">
                    <div class="col-sm-3 col-sm-offset-2">
                        <button type="submit" name="button" class="btn btn-success"><i class="fa fa-save"></i> Save</button>
                    </div>
                </div>
            </form>
        </div><!-- /.box-body -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>