<style>
@page  { margin: 0px; }
body {
    margin: 0px;
    font-family: helvetica;
    background: url('<?php echo e(asset('img/bg-ticket.png')); ?>')
}
</style>

<?php if($empty === false): ?>
    <span style="position: absolute; left: 18px; top: 48px;"><?php echo e($ticket->order ? $ticket->order->name : ''); ?></span>
    <span style="position: absolute; left: 18px; top: 106px;"><?php echo e($ticket->order ? $ticket->order->id_no : ''); ?></span>
    <span style="position: absolute; left: 18px; top: 168px;"><?php echo e($ticket->order ? $ticket->order->email : ''); ?></span>
    <span style="position: absolute; left: 18px; top: 228px;"><?php echo e($ticket->order ? $ticket->order->handphone : ''); ?></span>
<?php endif; ?>
<b style="position: absolute; left: 275px; top: 284px;"><?php echo e($ticket->unique_code); ?></b>
<b style="position: absolute; left: 150px; top: 284px;"><?php echo e($ticket->unique_code); ?></b>
<img src="<?php echo e(asset('/qrcodes/' . $ticket->generateBarcode() . '.png')); ?>" alt="Barcode here" style="position: absolute; right: 7px; top: 137.5px; width: 175px"/>
<!--<span style="position: absolute; left: 275px; top: 8px; color: #FFFFFF; text-transform: uppercase"><?php echo e($ticket->type->name); ?></span>-->
