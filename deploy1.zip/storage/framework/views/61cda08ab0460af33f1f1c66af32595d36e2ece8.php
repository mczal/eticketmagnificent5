<?php $__env->startSection('title', 'Order Detail #' . $order->no_order); ?>
<?php $__env->startSection('header', 'Order Detail'); ?>
<?php $__env->startSection('subheader', '#' . $order->no_order); ?>

<?php $__env->startSection('content'); ?>
    <p>
        <a href="<?php echo e(url('/orders/create-offline')); ?>" class="btn btn-primary"><i class="fa fa-plus"></i> Create new offline ticket</a>
        <a href="<?php echo e(url('/orders' )); ?>" class="btn btn-success"><i class="fa fa-bars"></i> View List</a>
    </p>
    <div class="box box-solid">
        <div class="box-header">
            <h3 class="box-title">General</h3>
        </div>
        <div class="box-body text-left">
            <div class="container">
                <!-- ID Number -->
                <div class="row">
                    <div class="form-group">
                        <label for="order-id_no" class="col-sm-2 control-label">ID Number</label>

                        <div class="col-sm-6">
                            <?php echo e($order->id_no); ?>

                        </div>
                    </div>
                </div>

                <!-- TICKET TYPE -->
                <div class="row">
                    <div class="form-group">
                        <label for="order-type_id" class="col-sm-2 control-label">Ticket Type</label>

                        <div class="col-sm-6">
                            <?php echo e($order->type != null ? $order->type->name : ''); ?>

                        </div>
                    </div>
                </div>

                <!-- Quantity -->
                <div class="row">
                    <div class="form-group">
                        <label for="order-quantity" class="col-sm-2 control-label">Quantity</label>

                        <div class="col-sm-6">
                            <?php echo e($order->quantity); ?> PCS
                        </div>
                    </div>
                </div>

                <!-- Total -->
                <div class="row">
                    <div class="form-group">
                        <label for="order-total" class="col-sm-2 control-label">Total</label>

                        <div class="col-sm-6">
                            IDR <?php echo e(number_format($order->total_price)); ?>

                        </div>
                    </div>
                </div>

                <!-- Name -->
                <div class="row">
                    <div class="form-group">
                        <label for="order-name" class="col-sm-2 control-label">Name</label>

                        <div class="col-sm-6">
                            <?php echo e($order->name); ?>

                        </div>
                    </div>
                </div>

                <!-- Email -->
                <div class="row">
                    <div class="form-group">
                        <label for="order-email" class="col-sm-2 control-label">Email</label>

                        <div class="col-sm-6">
                            <?php echo e($order->email); ?>

                        </div>
                    </div>
                </div>

                <!-- Status -->
                <div class="row">
                    <div class="form-group">
                        <label for="order-status" class="col-sm-2 control-label">Status</label>

                        <div class="col-sm-6">
                            <?php echo e(App\Order::getStatusList($order->status)); ?>

                        </div>
                    </div>
                </div>

                <!-- Created At -->
                <div class="row">
                    <div class="form-group">
                        <label for="order-created" class="col-sm-2 control-label">Created At</label>

                        <div class="col-sm-6">
                            <?php echo e($order->created_at); ?>

                        </div>
                    </div>
                </div>

                <!-- Expired Date -->
                <div class="row">
                    <div class="form-group">
                        <label for="expired-date" class="col-sm-2 control-label">Expired Date</label>

                        <div class="col-sm-2">
                            <?php echo e($order->expired_date); ?>

                        </div>
                        <?php if($order->status == App\Order::STATUS_ORDERED): ?>
                        <div class="col-sm-4">
                            <?php echo e($timeLeft); ?> Minutes Left to Canceled
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Control -->
                <div class="row">
                    <div class="form-group">
                        <div class="col-sm-6 col-sm-offset-2">
                          <!--
                            <form action="<?php echo e(url('/orders/' . $order->id)); ?>" method="post" style="display: inline">
                                <?php echo csrf_field(); ?>

                                <?php echo method_field('DELETE'); ?>


                                <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure want to delete this item?')"><i class="fa fa-trash-o"></i> Delete</button>
                            </form>
                          -->
                        </div>
                            <div class="col-sm-6 col-sm-offset-2">
                                <form action="<?php echo e(url('/orders/resend-mail-online-order')); ?>" method="post" style="display: inline">
                                    <?php echo csrf_field(); ?>

                                    <input type="hidden" name="id" value="<?php echo e($order->id); ?>">
                                    <button type="submit" class="btn btn-primary" onclick="return confirm('Are you sure want resend email online order?')"><i class="fa fa-share"></i> Resend Mail</button>
                                </form>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php if($order->status == App\Order::STATUS_PAID): ?>
    <div class="box box-solid">
        <div class="box-header">
            <h3 class="box-title">Tickets</h3>
        </div>
        <div class="box-body text-left">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th width="10px">No.</th>
                                    <th width="200px">Code</th>
                                    <th width="300px">Signature</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php /**/ $i = 1 /**/ ?>
                                <?php foreach($order->tickets as $ticket): ?>
                                    <tr>
                                        <td><?php echo e($i++); ?></td>
                                        <td><?php echo e($ticket->unique_code); ?></td>
                                        <td><?php echo e(strtoupper($ticket->generateBarcode())); ?></td>
                                        <td>
                                            <a href="<?php echo e(url('/tickets/print/' . $ticket->id)); ?>" target="_blank"><span class="fa fa-print"></span></a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>