<?php $__env->startSection('background',"url('/assets/images/background.jpg')no-repeat center center fixed;-webkit-background-size: cover;
-moz-background-size: cover;
-o-background-size: cover;
background-size: cover;"); ?>
<?php $__env->startSection('content'); ?>
<p style="text-align:center; padding-top:30px"><img src="<?php echo e(asset("/assets/images/tickets.png" )); ?>" width="250" height="auto"></p>
<div class="row">
	<div class="col-lg-6 col-lg-offset-3 col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2 col-xs-10 col-xs-offset-1"  style="background: rgba(38,38,38,0.8); padding-top:10px; padding-bottom:20px;">
		<p style="font-size:13pt;" align="center">Input your personal details below</p>
		<form action="<?php echo e(url('/buy')); ?>" method="post" role="form">
			<?php echo csrf_field(); ?>

			<div class="form-group">
				<div class="col-sm-12">
					<?php echo $__env->make('commons.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					<?php echo $__env->make('commons.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</div>
			</div>
			<div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
				<div class="col-sm-12">
					<label for="name">Name:
					<?php if($errors->has('name')): ?>
			            <span class="help-block">
			                <strong><?php echo e($errors->first('name')); ?></strong>
			            </span>
			        <?php endif; ?></label>
					<input type="text" class="form-control" name="name" id="name" style="margin-bottom: 20px;" value="<?php echo e(old('name')); ?>">
				</div>
			</div>
			<div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
				<div class="col-sm-12">
					<label for="email">Email:
					<?php if($errors->has('email')): ?>
			            <span class="help-block">
			                <strong><?php echo e($errors->first('email')); ?></strong>
			            </span>
			        <?php endif; ?></label>
					<input type="email" class="form-control" name="email" id="email" style="margin-bottom: 20px;" value="<?php echo e(old('email')); ?>">
				</div>
			</div>
			<div class="form-group<?php echo e($errors->has('id_no') ? ' has-error' : ''); ?>">
				<div class="col-sm-12">
					<label for="id_no">No. ID (KTP, KTM, SIM):
					<?php if($errors->has('id_no')): ?>
			            <span class="help-block">
			                <strong><?php echo e($errors->first('id_no')); ?></strong>
			            </span>
			        <?php endif; ?></label>
					<input type="text" class="form-control" name="id_no" id="id_no" style="margin-bottom: 20px;" value="<?php echo e(old('id_no')); ?>">
				</div>
			</div>
			<div class="form-group<?php echo e($errors->has('handphone') ? ' has-error' : ''); ?>">
				<div class="col-sm-12">
					<label for="handphone">Handphone:
					<?php if($errors->has('handphone')): ?>
			            <span class="help-block">
			                <strong><?php echo e($errors->first('handphone')); ?></strong>
			            </span>
			        <?php endif; ?></label>
					<input class="form-control" id="handphone" style="margin-bottom: 20px;" name="handphone" value="<?php echo e(old('handphone')); ?>">
				</div>
			</div>
			<div class="form-group<?php echo e($errors->has('quantity') ? ' has-error' : ''); ?>">
				<div class="col-sm-12">
					<label for="quantity">Number of tickets:</label>
					<select class="form-control" id="quantity" style="margin-bottom: 20px;" name="quantity">
						<option value="1"<?php echo e(old('quantity') == 1 ? ' selected' : ''); ?>>1</option>
						<option value="2"<?php echo e(old('quantity') == 2 ? ' selected' : ''); ?>>2</option>
						<option value="3"<?php echo e(old('quantity') == 1 ? ' selected' : ''); ?>>3</option>
					</select>
				</div>
			</div>
			<p align="center">
				<div class="col-sm-12">
					<label for="tiket sisa" >Number of tickets remaining:  </label>
					<label id="first" for="sisa"><?php echo e($remaining_tickets); ?> (@Rp.<?php echo e(number_format($price)); ?>)</label>
				</div>
			</p>
			<div class="col-sm-12">
				<input type="hidden" value="<?php echo e(env('ACTIVE_TICKET_TYPE')); ?>" name="type_id">
				<button id="second" style="font-size:11pt;" class="btn btn-lg btn-primary pull-right" type="submit" role="button">Submit</button>
			</div>
		</form>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>