<!-- TICKET TYPE -->
<div class="form-group<?php echo e($errors->has('type_id') ? ' has-error' : ''); ?>">
    <label for="order-type_id" class="col-sm-2 control-label">Ticket Type</label>

    <div class="col-sm-6">
        <select class="form-control" name="type_id" id="order-type_id">
            <?php foreach($types as $type): ?>
                <option value="<?php echo e($type->id); ?>"<?php echo e((isset($order) && $order->type_id == $type->id) || old('type_id') == $type->id ? ' selected' : ''); ?>><?php echo e($type->name); ?></option>
            <?php endforeach; ?>
        </select>

        <?php if($errors->has('type_id')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('type_id')); ?></strong>
            </span>
        <?php endif; ?>
    </div>
</div>

<!-- Name -->
<div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
    <label for="order-name" class="col-sm-2 control-label">Name</label>

    <div class="col-sm-6">
        <input type="text" name="name" id="order-name" class="form-control" value="<?php echo e(isset($order->name) ? $order->name : old('name')); ?>">
        <?php if($errors->has('name')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('name')); ?></strong>
            </span>
        <?php endif; ?>
    </div>
</div>

<!-- Email -->
<div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
    <label for="order-email" class="col-sm-2 control-label">Email</label>

    <div class="col-sm-6">
        <input type="email" name="email" id="order-email" class="form-control" value="<?php echo e(isset($order->email) ? $order->email : old('email')); ?>">
        <?php if($errors->has('email')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('email')); ?></strong>
            </span>
        <?php endif; ?>
    </div>
</div>

<!-- ID Number -->
<div class="form-group<?php echo e($errors->has('id_no') ? ' has-error' : ''); ?>">
    <label for="order-id_no" class="col-sm-2 control-label">ID Number</label>

    <div class="col-sm-6">
        <input type="text" name="id_no" id="order-id_no" class="form-control" value="<?php echo e(isset($order->id_no) ? $order->id_no : old('id_no')); ?>">
        <?php if($errors->has('id_no')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('id_no')); ?></strong>
            </span>
        <?php endif; ?>
    </div>
</div>

<!-- Quantity -->
<div class="form-group<?php echo e($errors->has('quantity') ? ' has-error' : ''); ?>">
    <label for="order-quantity" class="col-sm-2 control-label">Quantity</label>

    <div class="col-sm-2">
        <input type="number" name="quantity" id="order-quantity" class="form-control" value="<?php echo e(isset($order->quantity) ? $order->quantity : old('quantity')); ?>">
        <?php if($errors->has('quantity')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('quantity')); ?></strong>
            </span>
        <?php endif; ?>
    </div>
</div>
