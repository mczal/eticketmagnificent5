<?php $__env->startSection('title', 'Types'); ?>
<?php $__env->startSection('header', 'Types'); ?>
<?php $__env->startSection('subheader', 'Type List'); ?>

<?php $__env->startSection('content'); ?>
    <p>
        <a href="<?php echo e(url('/types/create' )); ?>" class="btn btn-primary"><i class="fa fa-plus"></i> Create new</a>
    </p>
    <div class="box box-solid">
        <div class="box-body">
            <?php echo $__env->make('commons.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <p>
                <form action="<?php echo e(url('/types')); ?>" method="get">
                    <div class="input-group">
                        <input type="text" class="form-control" name="name" value="<?php echo e($name); ?>" id="name" placeholder="Enter name to search ....">
                        <span class="input-group-btn">
                            <button class="btn btn-info btn-flat" type="submit"><i class="fa fa-search"></i></button>
                        </span>
                    </div>
                </form>
            </p>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Active</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($types) == 0): ?>
                        <tr>
                            <td colspan="4" align="center">No data found ...</td>
                        </tr>
                    <?php endif; ?>
                    <?php foreach($types as $type): ?>
                        <tr>
                            <td><?php echo e($type->id); ?></td>
                            <td><?php echo e($type->name); ?></td>
                            <td><?php echo e(number_format($type->price)); ?></td>
                            <td><?php echo e($type->active == 1 ? 'Active' : 'Not Active'); ?></td>
                            <td>
                                <a href="<?php echo e(url('/types/'.$type->id)); ?>" class="btn btn-default"><i class="fa fa-eye"></i></a>
                                <a href="<?php echo e(url('/types/'.$type->id.'/edit')); ?>" class="btn btn-default"><i class="fa fa-pencil"></i></a>
                                <a href="<?php echo e(url('/types/print/'.$type->id)); ?>" class="btn btn-default"><i class="fa fa-print"></i></a>
                                <form action="<?php echo e(url('/types/'.$type->id.'')); ?>" method="post" style="display:inline">
                                    <?php echo csrf_field(); ?>

                                    <?php echo method_field('DELETE'); ?>


                                    <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure want to delete this item?')"><i class="fa fa-trash-o"></i></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php echo $types->appends(['name' => $name])->links(); ?>

        </div><!-- /.box-body -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>