<?php $__env->startSection('title', 'Orders'); ?>
<?php $__env->startSection('header', 'Orders'); ?>
<?php $__env->startSection('subheader', 'Orders List'); ?>

<?php $__env->startSection('content'); ?>
    <p>
        <!-- <a href="<?php echo e(url('/orders/create-offline')); ?>" class="btn btn-primary"><i class="fa fa-plus"></i> Create new offline ticket</a> -->
    </p>
    <div class="box box-solid">
        <div class="box-body">
            <?php echo $__env->make('commons.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <p>
                <form action="<?php echo e(url('/orders')); ?>" method="get">
                    <div class="input-group">
                        <input type="text" class="form-control" name="no_order" value="<?php echo e($no_order); ?>" id="no_order" placeholder="Enter no order to search ....">
                        <input type="text" class="form-control" name="name" value="<?php echo e($name); ?>" id="name" placeholder="Enter Name to search ....">
                        <select class="form-control" name="status">
                          <option value="-1"<?php echo e(app('request')->input('status') == -1 ? ' selected' : ''); ?>>All</option>
                          <option value="1"<?php echo e(app('request')->input('status') == 1 ? ' selected' : ''); ?>>Ordered</option>
                          <option value="2"<?php echo e(app('request')->input('status') == 2 ? ' selected' : ''); ?>>Confirmed</option>
                          <option value="3"<?php echo e(app('request')->input('status') == 3 ? ' selected' : ''); ?>>Paid</option>
                          <option value="0"<?php echo e(app('request')->input('status') == 0 ? ' selected' : ''); ?>>Expire</option>
                        </select>
                        <span class="input-group-btn">
                            <button class="btn btn-info btn-flat" type="submit"><i class="fa fa-search"></i></button>
                        </span>
                    </div>
                </form>
            </p>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>No Order</th>
                        <th>Name</th>
                        <th>Handphone</th>
                        <th>Tgl Order</th>
                        <th>Status</th>
                        <th>Total</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($orders) == 0): ?>
                        <tr>
                            <td colspan="5" align="center">No data found ...</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach($orders as $order): ?>
                            <tr>
                                <td><?php echo e($order->no_order); ?></td>
                                <td><?php echo e($order->name); ?></td>
                                <td><?php echo e($order->handphone); ?></td>
                                <td><?php echo e(date('d M Y H:i:s', strtotime($order->created_at))); ?></td>
                                <td><?php echo e(App\Order::getStatusList($order->status)); ?></td>
                                <td>IDR <?php echo e(number_format($order->total_price)); ?></td>
                                <td>
                                    <a href="<?php echo e(url('/orders/'.$order->id)); ?>" class="btn btn-default"><i class="fa fa-eye"></i></a>
                                  <!--
                                    <form action="<?php echo e(url('/orders/'.$order->id.'')); ?>" method="post" style="display:inline">
                                        <?php echo csrf_field(); ?>

                                        <?php echo method_field('DELETE'); ?>


                                        <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure want to delete this item?')"><i class="fa fa-trash-o"></i></button>
                                    </form>
                                  -->
                                  <!--
                                  <a href="<?php echo e(url('/orders/'.$order->id.'/edit')); ?>" class="btn btn-default"><i class="fa fa-pencil"></i></a>
                                  -->
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php echo $orders->links(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>