<?php $__env->startSection('content'); ?>
<p>
    <a href="<?php echo e(url('/orders')); ?>" class="btn btn-primary"><i class="fa fa-bars"></i> View List</a>
</p>
<div class="box box-solid">
    <div class="box-header">
        <h3 class="box-title">General</h3>
    </div>
    <div class="box-body text-left">
        <form class="form-horizontal" action="<?php echo e(url('/orders/' . $order->id)); ?>" method="post">
            <?php echo csrf_field(); ?>

            <?php echo method_field('PATCH'); ?>

            <?php echo $__env->make('commons.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('commons.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <!-- Order Name -->
            <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                <label for="order-name" class="col-sm-2 control-label">Name</label>

                <div class="col-sm-6">
                    <input type="text" name="name" id="order-name" class="form-control" value="<?php echo e(isset($order->name) ? $order->name : old('name')); ?>">
                    <?php if($errors->has('name')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('name')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Order Address -->
            <div class="form-group<?php echo e($errors->has('address') ? ' has-error' : ''); ?>">
                <label for="order-address" class="col-sm-2 control-label">Address</label>

                <div class="col-sm-6">
                    <input type="text" name="address" id="order-address" class="form-control" value="<?php echo e(isset($order->address) ? $order->address : old('address')); ?>">
                    <?php if($errors->has('address')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('address')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Email -->
            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                <label for="order-email" class="col-sm-2 control-label">Email</label>

                <div class="col-sm-6">
                    <input type="email" name="email" id="order-email" class="form-control" value="<?php echo e(isset($order->email) ? $order->email : old('email')); ?>">
                    <?php if($errors->has('email')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Handphone -->
            <div class="form-group<?php echo e($errors->has('handphone') ? ' has-error' : ''); ?>">
                <label for="order-handphone" class="col-sm-2 control-label">Handphone</label>

                <div class="col-sm-6">
                    <input type="text" name="handphone" id="order-handphone" class="form-control" value="<?php echo e(isset($order->handphone) ? $order->handphone : old('handphone')); ?>">
                    <?php if($errors->has('handphone')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('handphone')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Control -->
            <div class="form-group">
                <div class="col-sm-3 col-sm-offset-2">
                    <button type="submit" name="button" class="btn btn-success"><i class="fa fa-save"></i> Save</button>
                </div>
            </div>

        </form>
    </div><!-- /.box-body -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>