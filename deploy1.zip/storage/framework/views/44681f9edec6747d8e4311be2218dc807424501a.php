<?php if(Session::has('success_message')): ?>
    <!-- Form Success Message -->
    <div class="alert alert-success">
        <?php echo Session::get('success_message'); ?>

    </div>
<?php endif; ?>
