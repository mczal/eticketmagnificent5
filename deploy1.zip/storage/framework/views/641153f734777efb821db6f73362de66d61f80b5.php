<ul class="sidebar-menu">
    <li class="header">MENU</li>
    <!--<li class="<?php echo e(Route::getCurrentRoute()->getPath() == 'types' ? ' active' : ''); ?>"><a href="<?php echo e(url('/types')); ?>"><span>Type</span></a></li> -->
    <li class="<?php echo e(Route::getCurrentRoute()->getPath() == 'tickets' ? ' active' : ''); ?>"><a href="<?php echo e(url('/tickets')); ?>"><span>Ticket</span></a></li>
    <li class="<?php echo e(Route::getCurrentRoute()->getPath() == 'orders' ? ' active' : ''); ?>"><a href="<?php echo e(url('/orders')); ?>"><span>Order</span></a></li>
    <li class="<?php echo e(Route::getCurrentRoute()->getPath() == 'confirmations' ? ' active' : ''); ?>"><a href="<?php echo e(url('/confirmations')); ?>"><span>Confirmation</span></a></li>
    <li class="<?php echo e(Route::getCurrentRoute()->getPath() == 'statistics' ? ' active' : ''); ?>"><a href="<?php echo e(url('/statistics')); ?>"><span>Statistics</span></a></li>
    <li><a href="<?php echo e(url('/logout')); ?>"><span>Logout</span></a></li>
</ul>
