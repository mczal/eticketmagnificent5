<?php if(Session::has('error_message')): ?>
    <!-- Form Error Message -->
    <div class="alert alert-danger">
        <?php echo Session::get('error_message'); ?>

    </div>
<?php endif; ?>
