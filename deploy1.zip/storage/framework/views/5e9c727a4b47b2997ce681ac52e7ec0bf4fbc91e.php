<?php $__env->startSection('title', 'Tickets'); ?>
<?php $__env->startSection('header', 'Tickets'); ?>
<?php $__env->startSection('subheader', 'Ticket List'); ?>

<?php $__env->startSection('content'); ?>
<!--
  <p>
      <a class="btn btn-primary" href=<?php echo e(url('/tickets/create')); ?> role="button"><i class="fa fa-plus"></i>  Create New</a>
  </p>
-->

  <div class="box box-solid">
      <div class="box-body">
        <p>
            <form action="<?php echo e(url('/tickets')); ?>" method="get">
                <div class="input-group">
                    <input type="text" class="form-control" name="unique_code" value="<?php echo e(app('request')->input('unique_code')); ?>" id="keyword" placeholder="Enter ticket code here to search ...."/>
                    <?php /**/ $i = 0 /**/ ?>
                    <div class="row">

                    </div>
                    <?php foreach($types as $type): ?>
                      <div class="checkbox">
                        <label>
                          <input id="ordered" type="checkbox" name="type[]" value="<?php echo e($type->id); ?>"<?php echo e(app('request')->input('type.'.$i.'') == $type->id ? ' checked '.$i++ : ''); ?>/><?php echo e($type->name); ?>

                        </label>
                      </div>
                    <?php endforeach; ?>
                    <select class="form-control" name="filter">
                      <option value="all"<?php echo e(app('request')->input('filter') == 'all' ? ' selected' : ''); ?>>All</option>
                      <option value="not_ordered"<?php echo e(app('request')->input('filter') == 'not_ordered' ? ' selected' : ''); ?>>Not Ordered</option>
                      <option value="ordered"<?php echo e(app('request')->input('filter') == 'ordered' ? ' selected' : ''); ?>>Ordered</option>
                      <option value="actived"<?php echo e(app('request')->input('filter') == 'actived' ? ' selected' : ''); ?>>Actived</option>
                      <option value="checked_in"<?php echo e(app('request')->input('filter') == 'checked_in' ? ' selected' : ''); ?>>Checked In</option>
                    </select>
                    <span class="input-group-btn">
                        <button class="btn btn-info btn-flat btn-lg" type="submit"><i class="fa fa-search"></i></button>
                    </span>
                </div>
            </form>
        </p>
          <table class="table table-striped table-hover">
            <thead>
              <tr>
                <th>Code</th>
                <th>Order</th>
                <th>Type</th>
                <th>Order Date</th>
                <th>Active Date</th>
                <th>Check-in Date</th>
                <th></th>
              </tr>
            </thead>
            <?php if( count($tickets) > 0 ): ?>
            <tbody>
              <?php foreach($tickets as $ticket): ?>
                  <tr>
                    <td><?php echo e($ticket->unique_code); ?></td>
                    <td><?php echo $ticket->order ? ($ticket->order->no_order.'<br>'.$ticket->order->name) : ''; ?></td>
                    <td><?php echo e($ticket->type->name); ?></td>
                    <td><?php echo e($ticket->order_date); ?></td>
                    <td><?php echo e($ticket->active_date); ?></td>
                    <td><?php echo e($ticket->check_in_date); ?></td>
                    <!--view edit delete-->
                    <td>
                      <a href="<?php echo e(url('/tickets/print/'.$ticket->id)); ?>" class="btn btn-default btn-primary" target="_blank"><i class="fa fa-print"></i></a>
                      <a href="<?php echo e(url('/tickets/'.$ticket->id)); ?>" class="btn btn-default"><i class="fa fa-eye"></i></a>
                      <!--
                      <a href="<?php echo e(url('/tickets/'.$ticket->id.'/edit')); ?>" class="btn btn-default"><i class="fa fa-pencil"></i></a>
                      <form action="<?php echo e(url('/tickets/'.$ticket->id)); ?>" method="post" style="display:inline">
                          <?php echo csrf_field(); ?>

                          <?php echo method_field('DELETE'); ?>


                          <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure want to delete this item?')"><i class="fa fa-trash-o"></i></button>
                      </form>
                    -->
                    </td>
                  </tr>
              <?php endforeach; ?>
            </tbody>
          <?php endif; ?>

          </table>
      </div>
  </div>
  <?php echo $tickets->links(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>